<template>
    <div id= "grid_cmp01">
        <section id="s1">
            <h2 id="h2c1">{{ msg1 }}</h2>
            <br>        
            <img alt="Vue logo" src="../assets/logo1.svg" width="200px" height="200px">
        </section>
        <br><br>
        <section id="s2" class="p-3 text-primary-emphasis bg-primary-subtle border border-primary-subtle rounded-3">
            <p id="p1">El valor ACTUAL de <strong>"MiVariable"</strong> es:  <strong>{{ miVariable }}</strong>
                <br>(OJO: En este componente se modifica el valor) 
            </p>
            <template v-if="miVariable === 'VALOR UNO'">
                <button id="bt1" @click="this.$store.dispatch('actualizarMiVariable', 'VALOR DOS')">Cambiar MiVariable</button>
            </template>
            <template v-else>
                <button id="bt2" @click="this.$store.dispatch('actualizarMiVariable', 'VALOR UNO')">Cambiar MiVariable</button>
            </template>
            <!-- 
                La instrucción this.$store.dispatch('miAccion', payload); se utiliza para ejecutar una acción en Vuex.
                this.$store: Es una referencia al almacén Vuex. Vuex es una biblioteca de gestión de estado para Vue.js.
                dispatch: Es un método de Vuex que se utiliza para ejecutar una acción. Las acciones son funciones que puedes definir en tu almacén Vuex.
                'miAccion': Es el nombre de la acción que deseas ejecutar.
                payload: Es el argumento que deseas pasar a la acción. Este argumento puede ser cualquier valor o estructura de datos que necesites para la acción.
            -->
        </section>                       
    </div>  
</template>

<script>
    export default {

        props: {
            msg1: String,
        },

        setup() {

            return {
            }; 
        },

        // Aquí se definen las propiedades computadas. Las propiedades computadas 
        // son funciones que se utilizan como una propiedad y se almacenan 
        // en caché basándose en sus dependencias. Esto significa que una propiedad 
        // computada solo se volverá a calcular cuando alguna de sus dependencias haya cambiado
        // Aquí cada que miVariable cambia se recalcula automáticamente
        computed: {   
            miVariable() {
                return this.$store.state.miVariable;
            },
        },

    };
</script>

<style>

* {
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
  }

#s1 {
    text-align: center;
}

#h2c1 {
    font-size: 25pt;
    font-weight: bolder;
}

#s2 {
    text-align: center;
}

#p1 {
    font-size: 15pt;
}

</style>