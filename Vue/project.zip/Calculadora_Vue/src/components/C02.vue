<template>
    <div id= "grid_cmp02" class="text-primary-emphasis bg-primary-subtle">
        <section id="s3">
            <h2 id="h2c2">{{ msg2 }}</h2>        
            <img alt="Vue logo" src="../assets/logo2.svg" width="200px" height="200px">
        </section>
        <br><br>
        <section id="s4" class="p-2 text-primary-emphasis bg-primary-subtle border border-primary-subtle rounded-3">
            <p id="p2">El valor ACTUAL de <strong>"MiVariable"</strong> es:  <strong>{{ miVariable }}</strong>
                <br>(OJO: En este componente se ve el valor modificado en el Componente 1)</p>
        </section>
        <br>
        <section id="s5" class="p-3 text-primary-emphasis bg-primary-subtle border border-primary-subtle rounded-3">
            <h3 id="h3c2">FORMULARIO</h3>
            <br><br>
            
            <label class="formulario" for="nombre">Nombres:  </label>
            <input id="nombre" class="formulario_in" type="text" v-model="Person.nombre">
            <br><br>

            <label class="formulario" for="apellido">Apellidos:  </label>
            <input id="apellido" class="formulario_in" type="text" v-model="Person.apellido">
            <br><br>

            <label class="formulario" for="codigo">Código:  </label>
            <input id="codigo" class="formulario_in" type="text" pattern="[0-9]{6}" title="El código es de 6 cifras" v-model="Person.codigo">
            <br><br>

            <label class="formulario" for="edad">Edad:  </label>
            <input id="edad" class="formulario_in" type="number" min="18" max="100" v-model="Person.edad">
            <br><br>

            <label class="formulario" for="tel">Teléfono: </label>
            <input id="tel" class="formulario_in" type="tel" v-model="Person.tel">
            <br><br><br>

            <!-- Button modal -->
            <button id="bt3" type="button" class="btn btn-primary" @click="this.$store.dispatch('actualizarPersona', Person)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                ENVIAR
            </button>
            <br><br>

            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content p-3 text-primary-emphasis bg-primary-subtle">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">¡AVISO!</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p id="modalcont">La información que acabas de ingresar puede ser revisada en el Componente 3</p>
                        </div>
                    </div>
                </div>
            </div> <!-- Fin Modal -->
               
        </section>
    </div>  
</template>

<script>

export default {

    props: {
        msg2: String,
    },

    setup() {

        // Variables

        let Person = {
            nombre: '',
            apellido: '',
            edad: null,
            tel: '',
            codigo: '',
        };

        return {
            Person,
        }; 
    },

    computed: {
        miVariable() {
            return this.$store.state.miVariable;
        },
    },

};
</script>

<style>

* {
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
  }

#s3 {
    text-align: center;
}

#h2c2 {
    font-size: 25pt;
    font-weight: bolder;
}

#s4 {
    text-align: center;
}

#h3c2 {
    text-align: center;
    font-size: 20pt;
    font-weight: bolder;
}

.formulario {
    padding-left: 10%;
    font-size: 14pt;
    font-weight: bold;
}

.formulario_in {
    padding-left: 7px;
    margin-left: 10px;
    font-size: 14pt;
}

#bt3 {
    margin-left: 47%;
}

#exampleModalLabel {
    font-weight: bold;
}

#modalcont {
    text-align: center;
    font-size: 15pt;
    font-weight: normal;
}

</style>