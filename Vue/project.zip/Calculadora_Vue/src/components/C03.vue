<template>
    <div id= "grid_cmp03">
        <section id="s6">
            <h2 id="h2c3">{{ msg3 }}</h2>        
            <img alt="Vue logo" src="../assets/logo3.svg" width="200px" height="200px"> 
        </section>
        <br>
        <section id="s7" class="p-3 text-primary-emphasis bg-primary-subtle border border-primary-subtle rounded-3"> 
            <p class="formulario">Información sobre <b>{{ Persona.nombre }} {{ Persona.apellido }}</b></p>
            <p class="formulario">Código: {{ Persona.codigo }}</p>     
            <p class="formulario">Edad: {{ Persona.edad }}</p>
            <p class="formulario">Teléfono: {{ Persona.tel }}</p>            
        </section>
    </div>   
</template>

<script>
export default {

    props: {
        msg3: String,
    },

    setup() {

        return {
        }; 

    },

    computed: {
        Persona() {
            return this.$store.state.Persona;
        },
    },

}
</script>

<style>

* {
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
  }

#s6 {
    text-align: center;
}

#h2c3 {
    font-size: 25pt;
    font-weight: bolder;
}

.formulario {
    padding-left: 10%;
    font-size: 14pt;
    font-weight: bold;
    text-transform: uppercase;
}

</style>