<template>
    <div>
        <C01 id="c1" msg1="ESTE ES EL C01 DENTRO DEL COMPONENTE 01"/>
    </div>
</template>

<script>
import C01 from '@/components/C01.vue'

export default {
    
    components: {
        C01,
    },

};
</script>

<style>

</style>