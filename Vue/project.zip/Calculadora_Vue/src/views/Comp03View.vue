<template>
    <div>
        <C03 msg3="ESTE ES EL C03 DENTRO DEL COMPONENTE 03"/>
    </div>  
</template>

<script>
import C03 from '@/components/C03.vue'

export default {
    
    components: {
        C03,
    },

};
</script>

<style>

</style>