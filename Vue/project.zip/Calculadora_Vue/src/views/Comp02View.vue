<template>
    <div>
        <C02 msg2="ESTE ES EL C02 DENTRO DEL COMPONENTE 02"/>
    </div>  
</template>

<script>
import C02 from '@/components/C02.vue'

export default {
    
    components: {
        C02,
    },

};

</script>

<style>

</style>