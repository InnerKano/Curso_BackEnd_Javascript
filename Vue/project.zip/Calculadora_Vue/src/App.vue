<template lang="es">
  <div id= "grid">

    <header id="encabezado" data-bs-theme="dark" class="p-3 m-0 bg-body-tertiary">
      <h1 id="h1app">PROYECTO EJEMPLO COMPLETO</h1>
    </header>

    <!-- Nav componente de bootstrap -->
    <nav id="menu_principal" class="navbar navbar-expand-lg p-2 m-0 bg-body-tertiary" data-bs-theme="dark">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <router-link to="/" class="nav-link" aria-current="page">INICIO</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/Comp01View" class="nav-link">COMPONENTE 1</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/Comp02View" class="nav-link">COMPONENTE 2</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/Comp03View" class="nav-link">COMPONENTE 3</router-link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- fin del Nav -->

    <main id="bloque_principal" class="p-3 m-0 text-primary-emphasis bg-primary-subtle">
      <router-view/>    
    </main>

    <footer id="pie_pagina" data-bs-theme="dark" class="p-3 m-0 bg-body-tertiary">
      <address><a href="mailto: contacto@gmail.com">contacto@gmail.com</a></address>
      <small>&copy; Derechos Reservados 2024</small>
      <br><br>
      <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/" target="_blank"><img alt="Licencia Creative Commons" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png"/></a>
      <br>
      <small>
        <span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">Ejemplo Proyecto Vue.js </span>por <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Ivonne Castaño Osorio</span> 
        <br>se distribuye bajo una<br> 
        <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/" target="_blank">Licencia Creative Commons Atribución-NoComercial-SinDerivadas 4.0 Internacional.</a>
      </small>
    </footer>

  </div>
</template>

<script>
  export default {

    components: {
    },

    setup() {

      return {
      }; 

    },
    
  };
</script>

<style scoped lang="css">

  * {
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
  }

  #grid { 
    display: grid;
    grid-gap: 5px;
    grid-template-columns: repeat(4, 25%);
    grid-template-rows: repeat(5, auto);

    grid-template-areas:    "H H H H"                             
                            "N N N N"
                            "M M M M"
                            "M M M M"
                            "F F F F";  
  }

  header {
    text-align: center;
    grid-area: H; 
  }

  #h1app {
    font-size: 40pt;
    color: ghostwhite;
    text-shadow: 5px 5px 5px khaki;
  }

  nav {
    grid-area: N; 
  }

  .nav-link {
    color: lightskyblue;
    font-weight: bolder;
  }

  .nav-link:hover {
    color: blue;
  }

  main {
    grid-area: M; 
  }

  footer {
    color: ghostwhite;
    text-align: center;
    font-weight: bold;
    margin: 10px;
    padding: 10px;
    padding-bottom: 30px;
    grid-area: F; 
  }

  address a {
    color: lightskyblue;
    text-decoration: none;
    font-weight: 600;
  }

  footer a {
    text-decoration: none;
  }

  a img {
    border-width: 0px;
  }

  @media screen and (max-width: 900px) and (min-width: 551px) { 
    #grid {        
      grid-template-columns: repeat(3, 33.3%);
      grid-template-rows: repeat(4, auto);

      grid-template-areas:    "H H H"
                              "N N N"                                
                              "M M M"                                                                
                              "F F F"; 
    }
  }

  @media screen and (max-width: 550px) {  
    #grid {        
      grid-template-columns: repeat(2, 50%);
      grid-template-rows: repeat(5, auto);

      grid-template-areas:    "H H"
                              "N N"
                              "M M"
                              "M M"                                                                  
                              "F F"; 
    }
  }
  
</style>
